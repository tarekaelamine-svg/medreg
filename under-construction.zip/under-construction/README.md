# Under Construction Starter (Static)

This folder contains a single-page **Coming Soon** site you can deploy for free.

Files:
- `index.html` – the page
- (you can add a `favicon.ico` later if you want)

Replace `YOURDOMAIN.COM` in `index.html` with your domain/email.

---

## Deploy Option A — Netlify (fast + free)

1) Go to https://app.netlify.com/ and sign in.
2) Click **Add new site → Deploy manually**. Drag-drop this folder, or connect a repo.
3) After deploy, open the site and click **Site configuration → Domains → Add custom domain**.
4) Enter your domain (e.g., `YOURDOMAIN.COM`). Netlify will show the DNS records you need.
5) In Name.com: **My Domains → Manage Domain → DNS Records** and add the records Netlify shows you:
   - Usually a **CNAME** for `www` → your `*.netlify.app` domain.
   - For the apex (`YOURDOMAIN.COM`), follow Netlify’s instructions (they'll show the exact record type/value).
6) Back in Netlify, click **Verify** (and enable HTTPS).

Tip: DNS changes aren’t instant everywhere; give them a bit to take effect.

---

## Deploy Option B — GitHub Pages (free)

1) Create a new GitHub repo and upload `index.html`.
2) In the repo: **Settings → Pages**. Set **Source** to **Deploy from a branch**, choose `main` and `/ (root)`.
3) GitHub shows a URL like `https://USERNAME.github.io/REPO`.
4) Still under **Settings → Pages**, set a **Custom domain** (e.g., `YOURDOMAIN.COM`); GitHub shows the DNS records to add.
5) In Name.com DNS, add those records exactly as shown (typically a CNAME for `www`).

---

## Deploy Option C — Name.com Website Builder (paid)

1) In Name.com, open your domain and choose **Website Builder**.
2) Pick a simple “Coming soon” template, publish, and connect your domain inside the builder.

---

## Optional tweaks

- Add a `favicon.ico` in the root.
- Change colors in the `<style>` block.
- Replace the `mailto:` form with a real email provider later (Brevo/Mailchimp/etc.).

